import React from 'react'
import AppRouters from './components/routers/AppRouters'
import './index.css';
import { AuthProvider } from './components/contexts/AuthProvider'; 


const App = () => {

  return (

    <AuthProvider>
      <div className="App">
        <AppRouters /> {/* Renderiza as rotas */}
      </div>
    </AuthProvider>
  )
}

export default App
