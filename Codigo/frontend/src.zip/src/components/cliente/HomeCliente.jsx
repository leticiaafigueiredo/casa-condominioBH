import React from 'react'
import Header from '../common/Header'
import Banner from '../home/Banner'
import ProdutoCarrosselEst from '../home/ProdutoCarrosselEst'
import SobreNos from '../home/SobreNos'
import Footer from '../common/Footer'

const HomeCliente = () => {

  

  return (
    <>
      
      <Header></Header> 
      <Banner/>
      <ProdutoCarrosselEst />
      <SobreNos></SobreNos>
      <Footer></Footer>

    </>
  )


}

export default HomeCliente
