import React from 'react'

const PerfilCliente = () => {
  return (
    <div>
      perfil do cliente
    </div>
  )
}

export default PerfilCliente
