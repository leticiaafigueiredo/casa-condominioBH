import React from 'react'

const PerfilAdmin = () => {
  return (
    <div>
      
    </div>
  )
}

export default PerfilAdmin
