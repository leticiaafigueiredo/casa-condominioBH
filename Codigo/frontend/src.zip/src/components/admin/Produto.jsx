"use client"

import { useState } from "react"
// import { Badge } from "@/components/ui/badge"
// import { Button } from "@/components/ui/button"
// import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
// import { Input } from "@/components/ui/input"
// import { Label } from "@/components/ui/label"
// import { Slider } from "@/components/ui/slider"
// import { Edit, Trash2 } from "lucide-react"


export default function AdminListagemProduto() {
  const [produtos, setProducts] = useState([]);
  const [categorias, setCategories] = useState([]);
  const [nameFilter, setNameFilter] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [priceRange, setPriceRange] = useState([0, 1500]);

  useEffect(() => {
    const fetchProdutos = async () => {
      try {
        const response = await axios.get("produto/listagem"); // Ajuste a URL conforme necessário
        setProducts(response.data);
      } catch (error) {
        console.error("Error fetching produtos:", error);
      }
    };

    const fetchCategorias = async () => {
      try {
        const response = await axios.get("categoria/getAll");
        setCategories(response.data); // Ajuste conforme o formato da resposta
      } catch (error) {
        console.error("Error fetching categorias:", error);
      }
    };

    fetchProdutos();
    fetchCategorias();
  }, []);

  const filteredProducts = produtos.filter(
    (product) =>
      product.name.toLowerCase().includes(nameFilter.toLowerCase()) &&
      (categoryFilter === "" || product.category === categoryFilter) &&
      product.price >= priceRange[0] &&
      product.price <= priceRange[1]
  )

  // const categorias = [...new Set(products.map((product) => product.category))]

  const handleEdit = (productId) => {
    navigate(`/produto/editar/${productId}`);
  };

  const handleDelete = (productId) => {
    console.log(`Deleting product with ID: ${productId}`)
    // Implement delete functionality here
  }

  return (
    // <div className="container mx-auto p-4">
    //   <h1 className="text-3xl font-bold mb-8">Manage Products</h1>
    //   <div className="flex flex-col md:flex-row gap-8">
    //     {/* Sidebar with filters */}
    //     <aside className="w-full md:w-1/4">
    //       <div className="space-y-6">
    //         <div>
    //           <Label htmlFor="name-filter">Product Name</Label>
    //           <Input
    //             id="name-filter"
    //             placeholder="Filter by name"
    //             value={nameFilter}
    //             onChange={(e) => setNameFilter(e.target.value)}
    //           />
    //         </div>
    //         <div>
    //           <Label htmlFor="category-filter">Category</Label>
    //           <select
    //             id="category-filter"
    //             className="w-full p-2 border rounded"
    //             value={categoryFilter}
    //             onChange={(e) => setCategoryFilter(e.target.value)}
    //           >
    //             <option value="">All Categories</option>
    //             {categorias.map((category) => (
    //               <option key={category} value={category}>
    //                 {category}
    //               </option>
    //             ))}
    //           </select>
    //         </div>
    //         <div>
    //           <Label>Price Range</Label>
    //           <Slider
    //             min={0}
    //             max={1500}
    //             step={10}
    //             value={priceRange}
    //             onValueChange={setPriceRange}
    //             className="mt-2"
    //           />
    //           <div className="flex justify-between mt-2">
    //             <span>${priceRange[0]}</span>
    //             <span>${priceRange[1]}</span>
    //           </div>
    //         </div>
    //       </div>
    //     </aside>

    //     {/* Product grid */}
    //     <main className="w-full md:w-3/4">
    //       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
    //         {filteredProducts.map((product) => (
    //           <Card key={product.id}>
    //             <CardHeader>
    //               <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-t" />
    //               <CardTitle>{product.name}</CardTitle>
    //             </CardHeader>
    //             <CardContent>
    //               <Badge variant="secondary">{product.category}</Badge>
    //               <p className="mt-2 text-2xl font-bold">${product.price}</p>
    //             </CardContent>
    //             <CardFooter className="flex justify-between">
    //               <Button variant="outline" size="sm" onClick={() => handleEdit(product.id)}>
    //                 <Edit className="h-4 w-4 mr-2" /> Edit
    //               </Button>
    //               <Button variant="destructive" size="sm" onClick={() => handleDelete(product.id)}>
    //                 <Trash2 className="h-4 w-4 mr-2" /> Delete
    //               </Button>
    //             </CardFooter>
    //           </Card>
    //         ))}
    //       </div>
    //     </main>
    //   </div>
    // </div>



    <div className="row">
      {produtos.map((produto) => (
        <div className="col-12 col-md-4 col-lg-3 mb-5 mb-md-0 mt-5" key={produto.id}>
          <Link className="product-item" href={`/produto/${produto.id}`}>
            <img src={produto.image} className="img-fluid product-thumbnail" alt={produto.nome} />
            <h3 className="product-title">{produto.nome}</h3>
            <strong className="product-price">${produto.preco}</strong>
            <span className="icon-cross">
              <i className="fa-solid fa-plus" style={{ color: "#ffffff" }}></i>
            </span>
          </Link>
        </div>
      ))}
    </div>






  )

}