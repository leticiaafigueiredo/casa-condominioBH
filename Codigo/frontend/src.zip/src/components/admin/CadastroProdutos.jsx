import React, { useState } from 'react';
import axios from 'axios';


const CadastroProdutos = () => {
  const [produto, setProduto] = useState({ nome: '', descricao: '' });
  const [imagens, setImagens] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [categoriasIds, setCategoriasIds] = useState([]);

  useEffect(() => {
    const fetchCategorias = async () => {
      try {
        const response = await axios.get('/categoria/getAll'); // Ajuste a rota conforme sua API
        setCategorias(response.data); // Supondo que a resposta contenha a lista de categorias
      } catch (error) {
        console.error('Erro ao carregar categorias:', error);
      }
    };
    fetchCategorias();
  }, []);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProduto({ ...produto, [name]: value });
  };

  const handleFileChange = (e) => {
    setImagens(e.target.files);
  };

  const handleSelectChange = (e) => {
    const options = e.target.options;
    const selectedIds = [];
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selectedIds.push(options[i].value);
      }
    }
    setCategoriasIds(selectedIds); // Atualizando o estado com os IDs selecionados
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const token = localStorage.getItem('token');

    try {

      const responseProduto = await axios.post('/produto/cadastrar', produto, {
        headers: {
          'Authorization': token, // Incluindo o token no cabeçalho
        },
      });
      const produtoId = responseProduto.data.id; // Assumindo que o ID é retornado no response

      // Preparar o FormData para enviar as imagens
      const formData = new FormData();
      for (let i = 0; i < imagens.length; i++) {
        formData.append('images', imagens[i]);
      }

      // Enviar as imagens para o produto cadastrado
      await axios.post(`/imagem/${produtoId}/cadastrar`, formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
          'Authorization': token,
        },
      });

      alert('Produto cadastrado com sucesso!');
    } catch (error) {
      console.error('Erro ao cadastrar produto:', error);
      alert('Erro ao cadastrar produto.');
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>
          Nome:
          <input
            type="text"
            name="nome"
            value={produto.nome}
            onChange={handleInputChange}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Descrição:
          <textarea
            name="descricao"
            value={produto.descricao}
            onChange={handleInputChange}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Imagens:
          <input
            type="file"
            multiple
            onChange={handleFileChange}
            required
          />
        </label>
      </div>
      <div>
        <label>
          Categorias:
          <select multiple onChange={handleSelectChange} required>
            {categorias.map(categoria => (
              <option key={categoria.categoriaId} value={categoria.categoriaId}>
                {categoria.nome} {/* Exibe o nome da categoria */}
              </option>
            ))}
          </select>
        </label>
      </div>
      <button type="submit">Cadastrar Produto</button>
    </form>
  );


}

export default CadastroProdutos;