import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useAuth } from '../contexts/AuthProvider'
import api from '../../api';

import Header from '../common/Header'

const CadastrarProdutos = () => {
    const { token, userType } = useAuth();

    const [produto, setProduto] = useState({
        nome: '',
        descricao: '',
        quantidade: '',
        preco: '',
        categoriasIds: []
    });
    const [imagens, setImagens] = useState([]);
    const [categorias, setCategorias] = useState([]);

    useEffect(() => {

        const fetchCategorias = async () => {
            try {
                const response = await axios.get('http://127.0.0.1:8080/categoria/getAll', {
                    headers: {
                        'Authorization': token, // Adiciona o token no cabeçalho
                    },
                });
                console.log('Categorias:', response.data);
                setCategorias(response.data);
            } catch (error) {
                console.error('Erro ao carregar categorias:', error);
            }
        };

        fetchCategorias();

    }, [token]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setProduto({ ...produto, [name]: value });
    };

    const handleFileChange = (e) => {
        setImagens(e.target.files);
    };

    const handleSelectChange = (e) => {
        const options = e.target.options;
        const selectedIds = [];
        for (let i = 0; i < options.length; i++) {
            if (options[i].selected) {
                selectedIds.push(options[i].value);
            }
        }
        setProduto({ ...produto, categoriasIds: selectedIds }); // Atualizando o estado com os IDs selecionados
    };

    const HandleSubmit = async (e) => {
        e.preventDefault();

        try {
            console.log('Token:', token);
            console.log(produto)

            const responseProduto = await axios.post('http://127.0.0.1:8080/produto/cadastrar', produto, {
                headers: {
                    'Authorization': token // Incluindo o token no cabeçalho
                },
            });

            console.log("Produto Cadastrado: ", responseProduto.data);
            const produtoId = responseProduto.data.produtoId; // Assumindo que o ID é retornado no response

            //Preparar o FormData para enviar as imagens
            const formData = new FormData();
            for (let i = 0; i < imagens.length; i++) {
                formData.append('images', imagens[i]);
            }

            console.log("id do produto: ", produtoId)

            console.log(formData)

            // Enviar as imagens para o produto cadastrado
            await axios.post(`http://127.0.0.1:8080/imagem/${produtoId}/cadastrar`, formData, {
                headers: {
                    'Content-Type': 'multipart/form-data',
                    'Authorization': token,
                },
            });

            alert('Produto cadastrado com sucesso!');
        } catch (error) {
            console.error('Erro ao cadastrar produto:', error);
            alert('Erro ao cadastrar produto.');
        }
    };

    return (
        <>
            <Header />
            <h1 className="text-center mt-4">Cadastrar Novo Produto</h1>
            <form onSubmit={HandleSubmit} className="container mt-4">

                <div className=" mb-3">
                    <label className="form-label" htmlFor="">Nome:</label>
                    <input type="text"
                        className="form-control"
                        name="nome"
                        value={produto.nome}
                        onChange={handleInputChange}
                        required />
                </div>
                <div className=" mb-3">
                    <label className="form-label" htmlFor="">
                        Descrição: </label>
                    <textarea name="descricao" id=""
                        className="form-control"
                        value={produto.descricao}
                        onChange={handleInputChange}
                        required></textarea>

                </div>
                <div className="mb-3">
                    <label className="form-label" htmlFor="">
                        Quantidade:
                    </label>
                    <input type="number" className="form-control" name="quantidade" id=""
                        value={produto.quantidade}
                        onChange={handleInputChange}
                        required />

                </div>
                <div>
                    <label className="mb-3" htmlFor="">
                        Preço:
                    </label>
                    <input type="number" name="preco"
                        className="form-control"
                        value={produto.preco}
                        onChange={handleInputChange}
                        required />

                </div>
                <div>
                    <label className="form-label">Categorias:</label>
                    <select multiple className="form-select" onChange={handleSelectChange} required>
                        {categorias.map(categoria => (
                            <option key={categoria.categoriaId} value={categoria.categoriaId}>
                                {categoria.nome} {/* Exibe o nome da categoria */}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label className="form-label">Imagem:</label>
                    <input type="file" className="form-control" multiple onChange={handleFileChange} required />
                </div>
                <button className="btn btn-primary" type="submit">Cadastrar Produto</button>
            </form>

        </>

    );
}

export default CadastrarProdutos;