"use client"

import { useState } from "react"

const  AdminListagemProduto = () =>{


}

export default AdminListagemProduto;