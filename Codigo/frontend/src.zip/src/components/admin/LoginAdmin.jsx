import React from 'react'

const LoginAdmin = () => {
  return (
    <div>
      
    </div>
  )
}

export default LoginAdmin
