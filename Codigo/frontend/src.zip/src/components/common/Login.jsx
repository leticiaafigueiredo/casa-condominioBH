import React from 'react'
import LoginCliente from '../cliente/LoginCliente'

const Login = () => {
    console.log("login")

    return (
            <LoginCliente />
    )
}

export default Login

