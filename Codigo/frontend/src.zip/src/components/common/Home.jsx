import React from 'react'

import Header from './Header'
import { useAuth } from '../contexts/AuthProvider'
import HomeCliente from '../cliente/HomeCliente'
import HomeAdmin from '../admin/HomeAdmin'
import ProdutoCard from '../home/ProdutoCard'
import ProdutoCarrosselEst from '../home/ProdutoCarrosselEst'
import Banner from '../home/Banner'
import SobreNos from '../home/SobreNos'
import Footer from './Footer'


const Home = () => {
  const { userType } = useAuth();

  return (
    <>
      <Header />
      {
        userType === 'USER' ? (
          <HomeCliente />
        ) : userType === 'ADMIN' ? (
          <HomeAdmin />
        ) : (
          <>

            <Banner />
            <ProdutoCarrosselEst />
            <SobreNos></SobreNos>
            <Footer></Footer>


            <i className="fa-solid fa-circle-plus"></i>
          </>
        )
      }
    </>


  );
}

export default Home;
