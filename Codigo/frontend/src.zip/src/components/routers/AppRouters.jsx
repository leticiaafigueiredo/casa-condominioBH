import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';

import Home from '../common/Home';
import CadastroCliente from '../cliente/CadastroCliente';
import Login from '../common/Login';
import LoginCliente from '../cliente/LoginCliente';
import HomeCliente from '../cliente/HomeCliente';
import PerfilCliente from '../cliente/PerfilCliente';
// import AdminEditarProduto from '../admin/EditarProduto';
import ListagemProduto from '../admin/Produto';
import PerfilAdmin from '../admin/PerfilAdmin';
import Carrinho from '../carrinhoDeCompras/Carrinho';
import CadastrarProduto from '../admin/CadastrarProduto';
import { useNavigate, Link } from 'react-router-dom';
import ListagemProdutoAdmin from '../admin/Listagem';
import EditarProduto from '../admin/EditarProduto';

const AppRouters = () => {
    return (
      <Router>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="/cadastrar-cliente" element={<CadastroCliente />} />
          {/* <Route path="/login" element={<Login />} /> */}
          <Route path="/login" element={<LoginCliente />} />
          <Route path="/home-cliente" element={<HomeCliente />} />
          <Route path="/perfil-cliente" element={<PerfilCliente />} /> 
          <Route path="/produto/listagem" element={<ListagemProduto />} /> 
          {/* <Route path="/cadastrar-produto" element={<CadastrarProduto/>}/> */}
          <Route path="/perfil-admin" element={<PerfilAdmin />} />
          <Route path="/carrinho" element={<Carrinho />} />
          <Route path='cadastrar-produto' element={<CadastrarProduto/>}></Route>
          <Route path='/listagem-produtos' element={<ListagemProdutoAdmin/>}></Route>
          <Route path='/editar-produto/:id' element={<EditarProduto/>}></Route>
        </Routes>
      </Router>
    );
  };
  
  export default AppRouters;
