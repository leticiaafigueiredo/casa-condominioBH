import React, { useState } from 'react';

const CadaProduto = (props) => {
    const [contador, setContador] = useState(0);
    const [total, setTotal] = useState(props.preco);

    const atualizarTotal = (newContador) => {
        setTotal(newContador * props.preco);
    };

    const incrementar = () => {
        setContador((prevContador) => {
            const newContador = prevContador + 1;
            atualizarTotal(newContador);
            return newContador;
        });
    };

    const decrementar = () => {
        setContador((prevContador) => {
            if (prevContador > 0) {
                const newContador = prevContador - 1;
                atualizarTotal(newContador);
                return newContador;
            }
            return prevContador; 
        });
    };

    return (
        <tr>
            <td className="product-thumbnail">
                <img src="images/product-1.png" alt="Image" className="img-fluid" />
            </td>
            <td className="product-name">
                <h2 className="h5 text-black">{props.nome}</h2>
            </td>
            <td>{props.preco}</td>
            <td>
                <div className="input-group mb-3 d-flex align-items-center quantity-container" style={{ maxWidth: 120 }}>
                    <div className="input-group-prepend">
                        <button className="btn btn-outline-black decrease" type="button" onClick={decrementar}>
                            <i className="fa-solid fa-minus"></i>
                        </button>
                    </div>
                    <input type="text" className="form-control text-center quantity-amount" value={contador} readOnly />
                    <div className="input-group-append">
                        <button className="btn btn-outline-black increase" type="button" onClick={incrementar}>
                            <i className="fa-solid fa-plus"></i>
                        </button>
                    </div>
                </div>
            </td>
            <td>{total}</td>
            <td><a href="#" className="btn btn-black btn-sm">X</a></td>
        </tr>
    );
};

export default CadaProduto;
