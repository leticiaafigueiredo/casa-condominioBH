import React from 'react';
import { Link } from 'react-router-dom';
import '../../assets/css/produtoCard.css'

const ProdutoCardAdmin = (props) => {
    return (
        <div className="col-12 col-md-4 col-lg-3 mb-5 mb-md-0 mt-5">
            <div className="card">
                <Link to={`/produto/${props.id}`}>
                    {props.img ? (
                        <img 
                            src={`data:image/jpeg;base64,${props.img}`} 
                            className="card-img-top" 
                            alt={props.nome} 
                        />
                    ) : (
                        <Link to={`/editar-produto/${props.id}`} className="no-image-link">
                            <div className="no-image-content text-decoration-none">
                                <i className="fas fa-image no-image-icon text-decoration-none"></i>
                                <p className="no-image-text text-decoration-none">Não possui imagem</p>
                            </div>
                        </Link>
                    )}
                </Link>
                <div className="card-body">
                    <h5 className="card-title">{props.nome}</h5>
                    <strong className="card-text">R$ {props.preco}</strong>
                    <div className="d-flex justify-content-between mt-3">
                        <Link to={`/editar-produto/${props.id}`}>
                            <button 
                                className="btn text-white me-2" 
                                style={{ backgroundColor: '#ffc107', border: 'none' }}
                            >
                                <i className="fa-solid fa-pencil-alt"></i> Editar Produto
                            </button>
                        </Link>
                        <button 
                            className="btn text-white" 
                            style={{ backgroundColor: '#dc3545', border: 'none' }}
                        >
                            <i className="fa-solid fa-trash"></i> Excluir Produto
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default ProdutoCardAdmin;
