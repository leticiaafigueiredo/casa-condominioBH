import React from 'react'
import { Link } from 'react-router-dom'
import '../../assets/css/produtoCard.css'

const ProdutoCard = (props) => {
    return (
        <div className="col-12 col-md-4 col-lg-3 mb-5 mb-md-0 mt-5">
            <Link to={`/produto/${props.id}`} className="product-item">
                {props.img ? (
                    <img 
                        src={`data:image/jpeg;base64,${props.img}`} 
                        className="img-fluid product-thumbnail" 
                        alt={props.nome} 
                    />
                ) : (
                    <Link to={`/editar-produto/${props.id}`} className="no-image-link">
                        <div className="no-image-content">
                            <i className="fas fa-image no-image-icon"></i>
                            <p className="no-image-text">Não possui imagem</p>
                        </div>
                    </Link>
                )}
                <h3 className="product-title">{props.nome}</h3>
                <strong className="product-price">R$ {props.preco}</strong>
            </Link>
        </div>
    );
};

export default ProdutoCard;
